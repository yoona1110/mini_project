import winreg

def delete_reg_value(root, path, name):
    try:
        key = winreg.OpenKey(root, path, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(key, name)
        print(f"[-] 삭제됨: {path}\\{name}")
    except FileNotFoundError:
        print(f"[i] 없음: {path}\\{name}")
    except Exception as e:
        print(f"[!] 삭제 실패: {path}\\{name} - {e}")

def restore_reg_values():
    delete_reg_value(winreg.HKEY_CURRENT_USER, r"Software\\Microsoft\\Windows\\CurrentVersion\\Run", "MaliciousApp")
    delete_reg_value(winreg.HKEY_CURRENT_USER, r"Software\\Classes\\.xyz", "Content Type")
    delete_reg_value(winreg.HKEY_CURRENT_USER, r"Console", "ColorTable00")
    delete_reg_value(winreg.HKEY_CURRENT_USER, r"Control Panel\\Desktop", "WallpaperStyle")

    try:
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\\Microsoft\\Windows\\CurrentVersion\\PushNotifications")
        winreg.SetValueEx(key, "ToastEnabled", 0, winreg.REG_DWORD, 1)
        print("[+] ToastEnabled 복원 완료")
    except Exception as e:
        print("[!] ToastEnabled 복원 실패:", e)

    delete_reg_value(winreg.HKEY_CURRENT_USER, r"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", "DisableRegistryTools")
    delete_reg_value(winreg.HKEY_CURRENT_USER, r"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", "DisableTaskMgr")
    delete_reg_value(winreg.HKEY_CURRENT_USER, r"Control Panel\\International", "sShortDate")
    delete_reg_value(winreg.HKEY_CURRENT_USER, r"Control Panel\\International", "sTimeFormat")
    delete_reg_value(winreg.HKEY_CURRENT_USER, r"Software\\VMware, Inc.\\VMware Tools", "InstallPath")

if __name__ == "__main__":
    print("[*] 레지스트리 복원 시작")
    restore_reg_values()
    print("[*] 복원 완료")
